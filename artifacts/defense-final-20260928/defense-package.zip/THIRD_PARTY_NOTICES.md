# Сторонние компоненты и данные

Актуальная поставка 28.09.2026: 26 институциональных источников, минимальные факты с точной атрибуцией; [условия и исключения](docs/SOURCE_INVENTORY.md). Лицензии npm не являются лицензиями на сайты. Камала, Culture.ru и KudaGo в публичном каталоге отсутствуют. PDF генерируется PyMuPDF 1.26.3 (AGPL-3.0 либо коммерческая лицензия; отдельный инструмент генерации, не зависимость бота). В публичном PDF используется встроенный шрифт Droid Sans Fallback из MuPDF; системные шрифты Windows не копируются. Исходник генератора включён. Изображения/логотипы учреждений не используются.

Операторский сборщик использует системный curl с обычной TLS-проверкой и закреплённым публичным DNS-адресом. Runtime-образ устанавливает Debian-пакеты `curl` и `ca-certificates`; системные copyright/notices в `/usr/share/doc` сохранены. Библиотеки npm и их lockfile не изменялись. Новые parser fixtures — минимальные вымышленные примеры разметки, не копии сайтов. Сырые ответы и два исследованных скана тарифов остаются в закрытом кеше и не входят в поставку.

Ниже сохранена инвентаризация зависимостей и историческое состояние G1.

# Сторонние компоненты G1

Дополнение 25.09.2026: HTML-парсер parse5 **8.0.0** — MIT; его закреплённая lockfile зависимость entities **6.0.1** — BSD-2-Clause. Их исходные LICENSE сохраняются в node_modules и Docker. DOM-парсер не исполняет HTML/JS и не загружает внешние сущности. Реальные данные двух учреждений — минимальные факты с собственным текстом карточек, отдельным [основанием и ограничениями](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/docs/pivot/17_REAL_CATALOG_AND_SOURCE_INTEGRATION.md); лицензии npm к этим фактам не применяются.

Прямые зафиксированные зависимости: Fastify 5.12.5, better-sqlite3 13.0.3, lossless-json 4.3.1 и zod 4.6.5 — MIT. TypeScript 7.0.2 — Apache-2.0; @types/node 22.20.4 и @types/better-sqlite3 9.6.0 — MIT. Источники лицензий — package.json/LICENSE опубликованных пакетов; integrity полного графа находится в package-lock.json. [Инвентаризация](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/docs/evidence/g1/dependencies.json) содержит каждую locked-версию, включая optional platform packages.

Node.js 22.23.2 распространяется с [собственным LICENSE и notices зависимостей](https://github.com/nodejs/node/blob/v22.23.2/LICENSE). SQLite — [public domain](https://www.sqlite.org/copyright.html). Caddy 2.11.4 — [Apache-2.0](https://github.com/caddyserver/caddy/blob/v2.11.4/LICENSE); бинарный официальный образ подготовлен только для будущего public окружения.

Dockerfile использует неизменённую основу официальных Node Debian bookworm images с зафиксированными digest; исходные системные notices `/usr/share/doc` остаются в runtime. Public Caddy image — Alpine, с сохранёнными upstream notices. Лицензии пакетов node_modules не удаляются при копировании в финальный образ. Builder содержит dev/compiler tools, runtime — только production graph и приложение. Это инвентаризация технического G1, не утверждение о готовности всего будущего пакета сдачи.

Свободно распространяемые компоненты не заменены закрытыми SDK. MAX подключён собственным небольшим адаптером к публично документированному API; SDK/код из внешних примеров не копировался. Синтетические фикстуры написаны для этого проекта. Лицензия самого пользовательского проекта автоматически не назначалась; публикация checkpoint не назначает её. Краткие нормализованные заметки pivot и ограничения источников — в [исследовании данных](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/docs/pivot/02_DATA_FEASIBILITY.md); тексты статей, изображения и API payload поставщиков не входят в публикацию.
