# Защитный комплект — измерение 28.09.2026

PDF/PPTX, редактируемые источники, инструкции, датированный каталог и evidence. Это не запускаемое приложение. Для запуска получите полный репозиторий версии [9de3d29ee0dfb9550e7809f8ea371b3f4cb6ce43](https://github.com/AiratBastanov/HackMaxBot2026/tree/9de3d29ee0dfb9550e7809f8ea371b3f4cb6ce43).

Начните с presentation/cultural-plan-submission-preview.pdf и docs/DEFENSE_BRIEF.md. Для изменения слайдов — presentation/README.md. VERSION.json разделяет приложение и dataset; MANIFEST.sha256 проверяет содержимое архива. Некоторые ссылки в инструкциях относятся к полному репозиторию. Рабочие секреты, БД и font-файлы исключены. Установка каталога и размещение не выполнялись.
