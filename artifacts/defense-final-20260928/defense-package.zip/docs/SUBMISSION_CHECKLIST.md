# Комплект сдачи

«Культурный план»: подбор событий и личные закладки в MAX. Каталог **28.09.2026 — 858 событий / 1 041 посещение / 11 городов / 26 источников**. [Версии и определения](DEFENSE_FACTS.json).

| Требование / материал | Документ |
|---|---|
| R07: назначение, сценарий, запуск, конфигурация, остановка | [README](../README.md), [самопроверка](ORGANIZER_CHECK.md) |
| R11: Docker, запуск всех компонентов одной командой | [Dockerfile](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/Dockerfile), [демо](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/compose.yaml), [реальный polling с подготовкой каталога](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/compose.polling.yaml) |
| R04: бот и независимая установка | [Бот](https://max.ru/t432_hakaton_max_bot), [свой токен и identity](../README.md#подключение-к-настоящему-max) |
| Постоянное размещение | [Webhook через HTTPS](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/deploy/compose.public.yaml), [операторская настройка](ORGANIZER_CHECK.md#постоянный-webhook) |
| C05: применимая API-поверхность | [OpenAPI](../openapi.json), [DATA-API](../DATA-API.yaml); отдельного бизнес-API нет, адрес и схема внешней интеграции задаются для выбранной установки |
| Данные и проверяемый сценарий | [Источники](SOURCE_INVENTORY.md), [снимок](../catalog/real/active.json), [автоматическое демо](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/scripts/organizer-check.ts) |
| Продуктовая презентация | [PDF: 13 слайдов](../presentation/cultural-plan.pdf), [редактируемый PPTX: 13](../presentation/cultural-plan.pptx) |
| Презентация с техническим первым листом | [PDF: 14 слайдов](../presentation/cultural-plan-submission-preview.pdf), [редактируемый PPTX: 14](../presentation/cultural-plan-submission-preview.pptx) |
| Версии и целостность | [Текущий защитный пакет](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/artifacts/defense-final-20260928/README.md): `VERSION.json`, `MANIFEST.sha256`, отдельный checksum архива |
| Приватность, компоненты и передача доступа | [Приватность](PRIVACY.md), [компоненты](../THIRD_PARTY_NOTICES.md), [закрытый шаблон](PRIVATE_HANDOFF_TEMPLATE.md) |

Участники: **Садыков Булат, Бастанов Айрат, Белова Маргарита**. Логин и пароль приложения не требуются: вход через MAX. Токен MAX передаётся отдельно через закрытый канал. Для самостоятельной установки используется токен собственного бота.

Технический первый лист содержит ссылку бота, репозиторий и точный commit, применимые сведения об API/доступе/окружении и краткий пользовательский путь. Продуктовые критерии: 40%, технические: 60%; требования PDF организатора, стр. 9–10 и 12. Для R11 сохранено [измерение чистой сборки](https://github.com/AiratBastanov/HackMaxBot2026/blob/main/docs/evidence/public-handoff/verification.json); текущие кешированные сборки не объявляются новым замером. [Брифинг для выступления](DEFENSE_BRIEF.md).
